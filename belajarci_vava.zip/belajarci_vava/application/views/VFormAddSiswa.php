<form action="<?php echo site_url('Welcome/AddDataSiswa'); ?>" method="post">
	NIS<input type="text" name="nis"><br>
	Nama<input type="text" name="nama"><br>
	Alamat<input type="text" name="alamat"><br>
	<input type="submit" name="simpan" value="Simpan">
</form>
